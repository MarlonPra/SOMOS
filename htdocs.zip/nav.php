    <!-- page Navigation -->
    <nav class="navbar custom-navbar navbar-expand-md navbar-light fixed-top" data-spy="affix" data-offset-top="10">
        <div class="container">
            <a class="navbar-brand" href="./">
                <img src="assets_somos/LOGO CON TITULO SIN FONDO-cropped.svg" alt="">
            </a>
            <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/#service">Nuestros Servicios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/#about">Sobre Nosotros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/terminos-y-condiciones">Términos y Condiciones</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="#contact">Contacto</a>
                    </li> -->
                    <li class="nav-item">
                        <a href="/contactanos" class="ml-4 nav-link btn btn-primary btn-sm rounded">Contáctanos</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- End Of Second Navigation -->