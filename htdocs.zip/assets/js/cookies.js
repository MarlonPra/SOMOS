$(document).ready(function () {
    // Verifica si las cookies han sido aceptadas previamente
    if (!localStorage.getItem("cookiesAccepted")) {
        $(".cookie-consent-banner").fadeIn();
        console.log("NO ACEPTADAS");
    }

    // Acción al aceptar las cookies
    $("#acceptCookies").click(function () {
        localStorage.setItem("cookiesAccepted", "true");
        $(".cookie-consent-banner").fadeOut();
        console.log("SI ACEPTADAS");
    });
});